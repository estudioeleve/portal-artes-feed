<?php
/**
 * Tema Portal ONE News — Studio Eleve.
 * Tudo em português. Áreas: destaque, Santa Luzia, canal exclusivo, colunistas,
 * Grande BH e Minas, vídeos, vitrine de anunciantes, editorias, mais lidas, anuncie.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ---------- configuração básica ---------- */
add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_image_size( 'po-card', 800, 500, true );
	add_image_size( 'po-mini', 240, 240, true );
	register_nav_menus( array( 'principal' => 'Menu de editorias (topo)', 'rodape' => 'Menu do rodapé' ) );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'po-fontes', 'https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700;800&display=swap', array(), null );
	wp_enqueue_style( 'po-tema', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );
	wp_enqueue_script( 'po-tema', get_template_directory_uri() . '/assets/tema.js', array(), wp_get_theme()->get( 'Version' ), true );
} );

/* ---------- conteúdos extras ---------- */
add_action( 'init', function () {
	register_post_type( 'po_video', array(
		'label' => 'Vídeos', 'public' => true, 'menu_icon' => 'dashicons-video-alt3', 'has_archive' => 'videos',
		'rewrite' => array( 'slug' => 'video' ), 'supports' => array( 'title', 'thumbnail' ), 'show_in_rest' => true,
		'labels' => array( 'name' => 'Vídeos', 'singular_name' => 'Vídeo', 'add_new_item' => 'Adicionar vídeo' ),
	) );
	register_post_type( 'po_anuncio', array(
		'label' => 'Anúncios', 'public' => false, 'show_ui' => true, 'menu_icon' => 'dashicons-megaphone',
		'supports' => array( 'title', 'thumbnail' ), 'show_in_rest' => true,
		'labels' => array( 'name' => 'Anúncios', 'singular_name' => 'Anúncio', 'add_new_item' => 'Adicionar anúncio' ),
	) );
	register_post_type( 'po_inscrito', array(
		'label' => 'Cadastros', 'public' => false, 'show_ui' => true, 'menu_icon' => 'dashicons-groups',
		'supports' => array( 'title' ), 'capabilities' => array( 'create_posts' => 'do_not_allow' ), 'map_meta_cap' => true,
		'labels' => array( 'name' => 'Cadastros (canal e anúncios)', 'singular_name' => 'Cadastro' ),
	) );
	foreach ( array( 'po_resumos', 'po_linha_fina', 'po_credito_foto', 'po_fonte' ) as $k ) {
		register_post_meta( 'post', $k, array( 'type' => 'string', 'single' => true, 'show_in_rest' => true ) );
	}
	register_post_meta( 'po_video', 'po_url', array( 'type' => 'string', 'single' => true, 'show_in_rest' => true ) );
	foreach ( array( 'po_posicao', 'po_link', 'po_preco', 'po_texto', 'po_colunista' ) as $k ) {
		register_post_meta( 'po_anuncio', $k, array( 'type' => 'string', 'single' => true, 'show_in_rest' => true ) );
	}
} );

/* ---------- caixas de campos no painel ---------- */
add_action( 'add_meta_boxes', function () {
	add_meta_box( 'po_post', 'Portal ONE News: destaque', 'po_box_post', 'post', 'normal', 'high' );
	add_meta_box( 'po_video', 'Link do vídeo', 'po_box_video', 'po_video', 'normal', 'high' );
	add_meta_box( 'po_anuncio', 'Dados do anúncio', 'po_box_anuncio', 'po_anuncio', 'normal', 'high' );
	add_meta_box( 'po_inscrito', 'Dados do cadastro', 'po_box_inscrito', 'po_inscrito', 'normal', 'high' );
} );
function po_campo( $id, $rot, $val, $tipo = 'text', $ajuda = '' ) {
	echo '<p><label for="' . esc_attr( $id ) . '"><strong>' . esc_html( $rot ) . '</strong></label><br>';
	if ( 'textarea' === $tipo ) echo '<textarea style="width:100%" rows="4" id="' . esc_attr( $id ) . '" name="' . esc_attr( $id ) . '">' . esc_textarea( $val ) . '</textarea>';
	else echo '<input style="width:100%" type="' . esc_attr( $tipo ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $id ) . '" value="' . esc_attr( $val ) . '">';
	if ( $ajuda ) echo '<br><small>' . esc_html( $ajuda ) . '</small>';
	echo '</p>';
}
function po_box_post( $p ) {
	wp_nonce_field( 'po_salvar', 'po_nonce' );
	po_campo( 'po_linha_fina', 'Linha fina (resumo abaixo do título)', get_post_meta( $p->ID, 'po_linha_fina', true ) );
	po_campo( 'po_resumos', 'Resumos do destaque (um por linha)', get_post_meta( $p->ID, 'po_resumos', true ), 'textarea', 'Aparecem como tópicos embaixo da manchete quando a notícia for o destaque principal.' );
	po_campo( 'po_credito_foto', 'Crédito da foto', get_post_meta( $p->ID, 'po_credito_foto', true ) );
	po_campo( 'po_fonte', 'Fonte', get_post_meta( $p->ID, 'po_fonte', true ) );
	echo '<p><small>Para virar o destaque principal da página inicial, marque "Fixar no topo do blog" no painel do lado.</small></p>';
}
function po_box_video( $p ) {
	wp_nonce_field( 'po_salvar', 'po_nonce' );
	po_campo( 'po_url', 'Link do YouTube ou do Instagram', get_post_meta( $p->ID, 'po_url', true ), 'url', 'Cole o link do vídeo. Ele toca dentro do site.' );
}
function po_box_anuncio( $p ) {
	wp_nonce_field( 'po_salvar', 'po_nonce' );
	$pos = get_post_meta( $p->ID, 'po_posicao', true );
	echo '<p><label for="po_posicao"><strong>Onde aparece</strong></label><br><select id="po_posicao" name="po_posicao">';
	foreach ( array( 'topo' => 'Banner grande 1 – no alto, logo na entrada (970 × 90)', 'meio' => 'Banner grande 2 – meio da página inicial (970 × 90)', 'lateral' => 'Banner quadrado 1 (300 × 250)', 'lateral2' => 'Banner quadrado 2 (300 × 250)', 'vitrine' => 'Vitrine de produto', 'videos' => 'Patrocínio da seção de vídeos', 'coluna' => 'Patrocinador de uma coluna (escolha o colunista abaixo)', 'portal-luziense' => 'Patrocinador do Portal Luziense', 'portal-comercio' => 'Patrocinador do Portal Comércio', 'portal-politica' => 'Patrocinador do Portal Política' ) as $v => $r ) {
		echo '<option value="' . esc_attr( $v ) . '"' . selected( $pos, $v, false ) . '>' . esc_html( $r ) . '</option>';
	}
	echo '</select></p>';
	$col = get_post_meta( $p->ID, 'po_colunista', true );
	echo '<p><label for="po_colunista"><strong>Colunista patrocinado (só para "Patrocinador de uma coluna")</strong></label><br><select id="po_colunista" name="po_colunista"><option value="">—</option>';
	foreach ( po_lista_colunistas( 100 ) as $u ) echo '<option value="' . esc_attr( $u->ID ) . '"' . selected( $col, (string) $u->ID, false ) . '>' . esc_html( $u->display_name . ' · ' . get_user_meta( $u->ID, 'po_coluna', true ) ) . '</option>';
	echo '</select></p>';
	po_campo( 'po_link', 'Link (site ou WhatsApp do anunciante)', get_post_meta( $p->ID, 'po_link', true ), 'url', 'WhatsApp: https://wa.me/5531999999999' );
	po_campo( 'po_inicio', 'Começa a aparecer em', get_post_meta( $p->ID, 'po_inicio', true ), 'date', 'Deixe vazio para começar já.' );
	po_campo( 'po_fim', 'Sai do ar depois de', get_post_meta( $p->ID, 'po_fim', true ), 'date', 'Deixe vazio para ficar no ar até você tirar.' );
	po_campo( 'po_preco', 'Preço (só para vitrine)', get_post_meta( $p->ID, 'po_preco', true ) );
	po_campo( 'po_texto', 'Texto curto (só para vitrine)', get_post_meta( $p->ID, 'po_texto', true ) );
	echo '<p><small>Use a "Imagem destacada" (no lado direito) para a arte do banner, no tamanho certo: 970 × 90 para os banners grandes e 300 × 250 para os quadrados. Se houver mais de um anúncio no mesmo espaço, eles se revezam a cada visita.</small></p>';
}
function po_box_inscrito( $p ) {
	foreach ( array( 'po_tipo' => 'Tipo', 'po_nome' => 'Nome', 'po_whats' => 'WhatsApp', 'po_bairro' => 'Cidade ou bairro', 'po_empresa' => 'Empresa', 'po_formato' => 'Formato de anúncio' ) as $k => $r ) {
		$v = get_post_meta( $p->ID, $k, true );
		if ( $v ) echo '<p><strong>' . esc_html( $r ) . ':</strong> ' . esc_html( $v ) . '</p>';
	}
}
add_action( 'save_post', function ( $id ) {
	if ( ! isset( $_POST['po_nonce'] ) || ! wp_verify_nonce( $_POST['po_nonce'], 'po_salvar' ) ) return;
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! current_user_can( 'edit_post', $id ) ) return;
	foreach ( array( 'po_linha_fina', 'po_credito_foto', 'po_fonte', 'po_preco', 'po_texto', 'po_posicao', 'po_colunista', 'po_inicio', 'po_fim' ) as $k ) {
		if ( isset( $_POST[ $k ] ) ) update_post_meta( $id, $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) );
	}
	if ( isset( $_POST['po_resumos'] ) ) update_post_meta( $id, 'po_resumos', sanitize_textarea_field( wp_unslash( $_POST['po_resumos'] ) ) );
	foreach ( array( 'po_url', 'po_link' ) as $k ) {
		if ( isset( $_POST[ $k ] ) ) update_post_meta( $id, $k, esc_url_raw( wp_unslash( $_POST[ $k ] ) ) );
	}
} );

/* ---------- colunistas: campos no perfil do usuário ---------- */
function po_campos_usuario( $u ) { ?>
	<h2>Colunista do Portal</h2>
	<table class="form-table">
		<tr><th><label for="po_coluna">Nome da coluna</label></th><td><input type="text" id="po_coluna" name="po_coluna" class="regular-text" value="<?php echo esc_attr( get_user_meta( $u->ID, 'po_coluna', true ) ); ?>"><p class="description">Preencha para a pessoa aparecer na seção Colunistas.</p></td></tr>
		<tr><th><label for="po_quem">Quem é</label></th><td><input type="text" id="po_quem" name="po_quem" class="regular-text" value="<?php echo esc_attr( get_user_meta( $u->ID, 'po_quem', true ) ); ?>"><p class="description">Uma linha curta. Ex.: "Advogado e professor de direito". O texto mais longo vai em "Informações biográficas", acima.</p></td></tr>
		<tr><th><label for="po_foto">Link da foto do colunista</label></th><td><input type="url" id="po_foto" name="po_foto" class="regular-text" value="<?php echo esc_attr( get_user_meta( $u->ID, 'po_foto', true ) ); ?>"><p class="description">Envie a foto na Biblioteca de Mídia e cole o link aqui.</p></td></tr>
	</table>
<?php }
add_action( 'show_user_profile', 'po_campos_usuario' );
add_action( 'edit_user_profile', 'po_campos_usuario' );
function po_salvar_usuario( $id ) {
	if ( ! current_user_can( 'edit_user', $id ) ) return;
	if ( isset( $_POST['po_coluna'] ) ) update_user_meta( $id, 'po_coluna', sanitize_text_field( wp_unslash( $_POST['po_coluna'] ) ) );
	if ( isset( $_POST['po_quem'] ) ) update_user_meta( $id, 'po_quem', sanitize_text_field( wp_unslash( $_POST['po_quem'] ) ) );
	if ( isset( $_POST['po_foto'] ) ) update_user_meta( $id, 'po_foto', esc_url_raw( wp_unslash( $_POST['po_foto'] ) ) );
}
add_action( 'personal_options_update', 'po_salvar_usuario' );
add_action( 'edit_user_profile_update', 'po_salvar_usuario' );

/* ---------- links do WhatsApp (canal e contato) ---------- */
define( 'PO_CANAL_PADRAO', 'https://whatsapp.com/channel/0029VbAl1JQLSmbejLg0uN0I' );
define( 'PO_ZAP_PADRAO', '5531992371702' );
function po_canal_link() { $l = get_theme_mod( 'po_canal_link' ); return $l ? $l : PO_CANAL_PADRAO; }
function po_zap_numero() { $n = preg_replace( '/\D/', '', (string) get_theme_mod( 'po_whats_noticia' ) ); return $n ? $n : PO_ZAP_PADRAO; }
function po_zap_contato() { return 'https://wa.me/' . po_zap_numero() . '?text=' . rawurlencode( 'Olá, Portal ONE News! Quero enviar uma denúncia / sugestão / reclamação: ' ); }
function po_icone_zap() { return '<svg class="zap-i" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a6.700 6.700 0 0 1-3.300-2.900c-.2-.4.2-.4.700-1.300.1-.2 0-.3 0-.5l-.8-1.800c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.200c0 1.300.9 2.600 1.100 2.800.1.200 1.900 2.900 4.600 4 1.700.7 2.400.8 3.200.7.500-.1 1.500-.6 1.700-1.200.2-.6.2-1.100.2-1.200-.1-.2-.3-.2-.5-.3z"/></svg>'; }

/* ---------- personalizar: links do WhatsApp ---------- */
add_action( 'customize_register', function ( $c ) {
	$c->add_section( 'po_contato', array( 'title' => 'Portal ONE News: WhatsApp e textos', 'priority' => 30 ) );
	$campos = array(
		'po_canal_link' => array( 'Link do canal exclusivo no WhatsApp', PO_CANAL_PADRAO ),
		'po_whats_comercial' => array( 'WhatsApp comercial (só números, com DDD)', '' ),
		'po_whats_noticia' => array( 'WhatsApp para o leitor mandar denúncia, sugestão ou reclamação (só números, com DDD)', PO_ZAP_PADRAO ),
		'po_seguidores' => array( 'Número de seguidores no Instagram (texto)', '137 mil' ),
		'po_aviso' => array( 'Faixa de aviso no topo (deixe vazio para esconder)', '' ),
			'po_logo_comercio' => array( 'Trocar a logo do Portal Comércio (link de PNG branca; vazio = logo do tema)', '' ),
			'po_logo_politica' => array( 'Trocar a logo do Portal Política (link de PNG branca; vazio = logo do tema)', '' ),
			'po_youtube' => array( 'Link do canal no YouTube', '' ),
			'po_instagram' => array( 'Link do Instagram', 'https://www.instagram.com/portalonenews/' ),
	);
	foreach ( $campos as $id => $d ) {
		$c->add_setting( $id, array( 'default' => $d[1], 'sanitize_callback' => 'sanitize_text_field' ) );
		$c->add_control( $id, array( 'label' => $d[0], 'section' => 'po_contato', 'type' => 'text' ) );
	}
} );

/* ---------- formulários: canal exclusivo e anuncie ---------- */
function po_receber_form() {
	if ( ! isset( $_POST['po_form_nonce'] ) || ! wp_verify_nonce( $_POST['po_form_nonce'], 'po_form' ) ) wp_die( 'Formulário expirado. Volte e tente de novo.' );
	if ( ! empty( $_POST['site'] ) ) wp_safe_redirect( home_url( '/' ) ) && exit; // armadilha de robô
	$tipo = ( isset( $_POST['po_tipo'] ) && 'anuncie' === $_POST['po_tipo'] ) ? 'anuncie' : 'canal';
	$d = array();
	foreach ( array( 'po_nome', 'po_whats', 'po_bairro', 'po_empresa', 'po_formato' ) as $k ) {
		$d[ $k ] = isset( $_POST[ $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) : '';
	}
	$id = wp_insert_post( array( 'post_type' => 'po_inscrito', 'post_status' => 'publish', 'post_title' => ( 'canal' === $tipo ? 'Canal: ' : 'Anúncio: ' ) . $d['po_nome'] . ' ' . $d['po_whats'] ) );
	if ( $id && ! is_wp_error( $id ) ) {
		update_post_meta( $id, 'po_tipo', 'canal' === $tipo ? 'Canal exclusivo' : 'Quer anunciar' );
		foreach ( $d as $k => $v ) update_post_meta( $id, $k, $v );
	}
	if ( 'canal' === $tipo && get_theme_mod( 'po_canal_link' ) ) wp_redirect( get_theme_mod( 'po_canal_link' ) );
	else wp_safe_redirect( add_query_arg( 'enviado', $tipo, home_url( '/' ) ) . '#' . ( 'canal' === $tipo ? 'canal' : 'anuncie' ) );
	exit;
}
add_action( 'admin_post_nopriv_po_form', 'po_receber_form' );
add_action( 'admin_post_po_form', 'po_receber_form' );

/* ---------- mais lidas: contador simples ---------- */
add_action( 'wp_head', function () {
	if ( is_single() && ! is_user_logged_in() ) {
		$id = get_the_ID();
		update_post_meta( $id, 'po_views', (int) get_post_meta( $id, 'po_views', true ) + 1 );
	}
} );

/* ---------- utilidades usadas nos modelos ---------- */
function po_editoria( $id = null ) {
	$cats = get_the_category( $id );
	if ( ! $cats ) return null;
	foreach ( $cats as $c ) if ( 'santa-luzia' === $c->slug ) return $c;
	foreach ( $cats as $c ) if ( 'uncategorized' !== $c->slug && (int) get_option( 'default_category' ) !== $c->term_id ) return $c;
	return null;
}
function po_hora( $id = null ) {
	$t = get_post_time( 'U', true, $id );
	if ( wp_date( 'Ymd' ) === wp_date( 'Ymd', $t ) ) return 'Hoje, ' . wp_date( 'H:i', $t );
	if ( wp_date( 'Ymd', time() - DAY_IN_SECONDS ) === wp_date( 'Ymd', $t ) ) return 'Ontem, ' . wp_date( 'H:i', $t );
	return wp_date( 'd/m/Y', $t );
}
function po_data_hoje() {
	$dias = array( 'Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado' );
	$meses = array( 1 => 'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro' );
	return $dias[ (int) wp_date( 'w' ) ] . ', ' . wp_date( 'j' ) . ' de ' . $meses[ (int) wp_date( 'n' ) ] . ' de ' . wp_date( 'Y' );
}
/** Cor da editoria (títulos coloridos no modelo Globo). */
function po_cor( $id ) {
	$c = po_editoria( $id );
	if ( ! $c ) return 'azul';
	$slugs = array( $c->slug );
	if ( $c->parent ) { $pai = get_category( $c->parent ); if ( $pai && ! is_wp_error( $pai ) ) $slugs[] = $pai->slug; }
	$mapa = array( 'esporte' => 'verde', 'entretenimento' => 'laranja', 'politica' => 'preto', 'comercio' => 'comercio', 'luto' => 'preto' );
	foreach ( $slugs as $sl ) if ( isset( $mapa[ $sl ] ) ) return $mapa[ $sl ];
	return 'azul';
}
/** Foto da notícia, ou um espaço cinza quando não houver. */
function po_img( $id, $tam = 'po-card' ) {
	return has_post_thumbnail( $id ) ? get_the_post_thumbnail( $id, $tam, array( 'class' => 'foto', 'alt' => '', 'loading' => 'lazy' ) ) : '<div class="sem-foto"></div>';
}
/** Card do destaque (colunas ao lado da manchete): foto, título colorido e um tópico. */
function po_card_g( $id ) {
	$res = array_filter( array_map( 'trim', explode( "\n", (string) get_post_meta( $id, 'po_resumos', true ) ) ) );
	echo '<article><a class="card-g" href="' . esc_url( get_permalink( $id ) ) . '">' . po_img( $id ) . '<h2 class="c-' . esc_attr( po_cor( $id ) ) . '">' . esc_html( get_the_title( $id ) ) . '</h2>';
	if ( $res ) echo '<span class="sub">' . esc_html( reset( $res ) ) . '</span>';
	echo '</a></article>';
}
/** Card de notícia. $estilo: 'card' (foto em cima) ou 'linha' (foto ao lado). */
function po_card( $id, $estilo = 'card', $cor = '' ) {
	$ed = po_editoria( $id );
	$cor = $cor ? $cor : po_cor( $id );
	if ( 'linha' === $estilo ) {
		echo '<a class="linha-n" href="' . esc_url( get_permalink( $id ) ) . '">' . ( has_post_thumbnail( $id ) ? get_the_post_thumbnail( $id, 'po-card', array( 'class' => 'foto', 'alt' => '', 'loading' => 'lazy' ) ) : '' ) . '<h3 class="c-' . esc_attr( $cor ) . '">' . esc_html( get_the_title( $id ) ) . '</h3></a>';
		return;
	}
	echo '<article><a class="card-p" href="' . esc_url( get_permalink( $id ) ) . '">' . po_img( $id );
	if ( $ed ) echo '<span class="ed c-' . esc_attr( $cor ) . '">' . esc_html( $ed->name ) . '</span>';
	echo '<h3>' . esc_html( get_the_title( $id ) ) . '</h3><span class="hora">' . esc_html( po_hora( $id ) ) . '</span></a></article>';
}
/** Busca posts sem repetir os já mostrados na página. */
function po_posts( $args, &$usados ) {
	$args = wp_parse_args( $args, array( 'posts_per_page' => 4, 'ignore_sticky_posts' => true, 'post_status' => 'publish', 'no_found_rows' => true ) );
	$args['post__not_in'] = array_merge( isset( $args['post__not_in'] ) ? $args['post__not_in'] : array(), $usados );
	$ids = get_posts( array_merge( $args, array( 'fields' => 'ids' ) ) );
	$usados = array_merge( $usados, $ids );
	return $ids;
}
function po_anuncios( $posicao, $qtd = 1, $colunista = 0 ) {
	$mq = array( array( 'key' => 'po_posicao', 'value' => $posicao ) );
	if ( $colunista ) $mq[] = array( 'key' => 'po_colunista', 'value' => (string) $colunista );
	$hoje = wp_date( 'Y-m-d' );
	$lista = array();
	foreach ( get_posts( array( 'post_type' => 'po_anuncio', 'posts_per_page' => 60, 'meta_query' => $mq ) ) as $a ) {
		$ini = get_post_meta( $a->ID, 'po_inicio', true ); $fim = get_post_meta( $a->ID, 'po_fim', true );
		if ( $ini && $ini > $hoje ) continue;
		if ( $fim && $fim < $hoje ) continue;
		$lista[] = $a;
	}
	shuffle( $lista ); // vários anúncios no mesmo espaço se revezam
	return array_slice( $lista, 0, $qtd );
}

/** Banner: mostra o anúncio cadastrado ou um espaço discreto "Anuncie aqui". */
function po_banner( $posicao, $classe, $rotulo, $chamada = '' ) {
	$a = po_anuncios( $posicao );
	echo '<div class="pub ' . esc_attr( $classe ) . '"><small>Publicidade</small>';
	if ( $a && has_post_thumbnail( $a[0] ) ) {
		$link = get_post_meta( $a[0]->ID, 'po_link', true );
		echo '<a href="' . esc_url( $link ? $link : home_url( '/#anuncie' ) ) . '" rel="sponsored noopener" target="_blank">' . get_the_post_thumbnail( $a[0], 'large', array( 'alt' => esc_attr( get_the_title( $a[0] ) ) ) ) . '</a></div>';
		return;
	}
	/* sem anunciante: anúncio da própria casa, no visual do portal (nunca um quadro vazio) */
	$logo = '<img src="' . esc_url( get_template_directory_uri() . '/assets/logo.png' ) . '" alt="Portal ONE News">';
	$url  = esc_url( home_url( '/#anuncie' ) );
	if ( 'lb' === $classe ) {
		echo '<a class="casa casa-lb" href="' . $url . '">' . $logo . '<span class="t"><b>Sua marca no portal de notícias da Grande BH</b><span>Banners, patrocínio de colunas e portais e matérias patrocinadas</span></span><span class="bt-c">Anuncie aqui</span></a></div>';
	} else {
		echo '<a class="casa casa-ret" href="' . $url . '">' . $logo . '<b>Sua marca aqui, ao lado das notícias mais lidas da região</b><span class="bt-c">Fale com o comercial</span></a></div>';
	}
}
/** "Oferecido por": patrocinador de coluna ou de portal. */
function po_patrocinador( $posicao, $colunista = 0 ) {
	$a = po_anuncios( $posicao, 1, $colunista );
	if ( ! $a ) return '';
	$link = get_post_meta( $a[0]->ID, 'po_link', true );
	$img = has_post_thumbnail( $a[0] ) ? get_the_post_thumbnail( $a[0], 'medium', array( 'alt' => esc_attr( get_the_title( $a[0] ) ) ) ) : '<b>' . esc_html( get_the_title( $a[0] ) ) . '</b>';
	return '<a class="of" href="' . esc_url( $link ? $link : '#' ) . '" rel="sponsored noopener" target="_blank">Oferecido por ' . $img . '</a>';
}
/** Colunistas: usuários com "Nome da coluna" preenchido. */
function po_lista_colunistas( $qtd = 4 ) {
	return get_users( array( 'meta_key' => 'po_coluna', 'meta_compare' => '!=', 'meta_value' => '', 'number' => $qtd, 'orderby' => 'ID', 'order' => 'ASC' ) );
}
function po_avatar( $u, $classe = 'av' ) {
	$foto = get_user_meta( $u->ID, 'po_foto', true );
	if ( $foto ) return '<img class="' . esc_attr( $classe ) . '" src="' . esc_url( $foto ) . '" alt="">';
	$ini = mb_strtoupper( mb_substr( $u->first_name ? $u->first_name : $u->display_name, 0, 1 ) . mb_substr( $u->last_name, 0, 1 ) );
	return '<span class="' . esc_attr( $classe ) . '">' . esc_html( $ini ) . '</span>';
}
/** Link de uma editoria pelo slug. */
function po_link_cat( $slug ) {
	$c = get_category_by_slug( $slug );
	return $c ? get_category_link( $c ) : home_url( '/' );
}
/** Os portais do ecossistema: cada um tem link próprio (/portal-luziense/ etc.). */
function po_portais() {
	return array(
		'luziense' => array( 'nome' => 'Portal Luziense', 'cat' => 'santa-luzia', 'cor' => 'luz', 'logo' => get_template_directory_uri() . '/assets/luziense.png', 'desc' => 'As notícias de Santa Luzia.' ),
		'comercio' => array( 'nome' => 'Portal Comércio', 'cat' => 'comercio', 'cor' => 'com', 'logo' => get_theme_mod( 'po_logo_comercio' ) ? get_theme_mod( 'po_logo_comercio' ) : get_template_directory_uri() . '/assets/comercio.png', 'desc' => 'Comércio, empresas e oportunidades da região.' ),
		'politica' => array( 'nome' => 'Portal Política', 'cat' => 'politica', 'cor' => 'pol', 'logo' => get_theme_mod( 'po_logo_politica' ) ? get_theme_mod( 'po_logo_politica' ) : get_template_directory_uri() . '/assets/politica.png', 'desc' => 'Política de Santa Luzia, da Grande BH e de Minas.' ),
	);
}
function po_portal_url( $chave ) { return home_url( '/portal-' . $chave . '/' ); }
/** Selo do portal: logo quando houver, senão o nome. */
function po_selo( $chave ) {
	$todos = po_portais();
	$p = $todos[ $chave ];
	return '<span class="selo f-' . esc_attr( $p['cor'] ) . '">' . ( $p['logo'] ? '<img src="' . esc_url( $p['logo'] ) . '" alt="' . esc_attr( $p['nome'] ) . '">' : esc_html( mb_strtolower( $p['nome'] ) ) ) . '</span>';
}
add_action( 'init', function () {
	foreach ( po_portais() as $k => $p ) {
		add_rewrite_rule( '^portal-' . $k . '/page/([0-9]+)/?$', 'index.php?category_name=' . $p['cat'] . '&po_portal=' . $k . '&paged=$matches[1]', 'top' );
		add_rewrite_rule( '^portal-' . $k . '/?$', 'index.php?category_name=' . $p['cat'] . '&po_portal=' . $k, 'top' );
	}
} );
add_filter( 'query_vars', function ( $v ) { $v[] = 'po_portal'; return $v; } );
/* garante os links dos portais: se o WordPress ainda não conhece /portal-luziense/ etc., atualiza as regras sozinho (uma vez) */
add_action( 'init', function () {
	$regras = get_option( 'rewrite_rules' );
	if ( ! is_array( $regras ) || ! isset( $regras['^portal-luziense/?$'] ) || ! isset( $regras['^portal-comercio/?$'] ) || ! isset( $regras['^portal-politica/?$'] ) ) {
		foreach ( array( 'santa-luzia' => 'Santa Luzia', 'comercio' => 'Comércio', 'politica' => 'Política' ) as $sl => $nm ) {
			if ( ! get_category_by_slug( $sl ) ) wp_insert_term( $nm, 'category', array( 'slug' => $sl ) );
		}
		flush_rewrite_rules( false );
	}
}, 99 );
/* página de portal nunca dá "não encontrada", mesmo antes de ter notícias */
add_action( 'template_redirect', function () {
	if ( get_query_var( 'po_portal' ) && is_404() ) {
		global $wp_query;
		$wp_query->is_404 = false; $wp_query->is_archive = true; $wp_query->is_category = true;
		status_header( 200 );
	}
}, 1 );
/** Busca: só notícias. */
add_action( 'pre_get_posts', function ( $q ) {
	if ( ! is_admin() && $q->is_main_query() && $q->is_search() ) $q->set( 'post_type', 'post' );
} );
function po_embed_video( $url ) {
	$html = wp_oembed_get( $url );
	return $html ? $html : '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">Assistir ao vídeo</a>';
}

/** Menu do topo: links simples; item com a classe "sl" fica dourado (Santa Luzia). */
class PO_Menu_Walker extends Walker_Nav_Menu {
	public function start_el( &$out, $item, $depth = 0, $args = null, $id = 0 ) {
		$sl = in_array( 'sl', (array) $item->classes, true ) || false !== stripos( $item->title, 'Santa Luzia' );
		$out .= '<a' . ( $sl ? ' class="sl"' : '' ) . ' href="' . esc_url( $item->url ) . '">' . esc_html( $item->title ) . '</a>';
	}
	public function end_el( &$out, $item, $depth = 0, $args = null ) {}
}

/* ---------- configuração automática (roda uma vez, logo depois de ativar o tema) ---------- */
add_action( 'admin_init', function () {
	if ( get_option( 'po_setup' ) === '2.0' || ! current_user_can( 'manage_options' ) ) return;
	$cats = array(
		'santa-luzia' => array( 'Santa Luzia', '' ),
		'grande-bh' => array( 'Grande BH', '' ),
		'belo-horizonte' => array( 'Belo Horizonte', 'grande-bh' ),
		'regiao-metropolitana' => array( 'Região Metropolitana', 'grande-bh' ),
		'contagem' => array( 'Contagem', 'grande-bh' ),
		'betim' => array( 'Betim', 'grande-bh' ),
		'vespasiano' => array( 'Vespasiano', 'grande-bh' ),
		'lagoa-santa' => array( 'Lagoa Santa', 'grande-bh' ),
		'ribeirao-das-neves' => array( 'Ribeirão das Neves', 'grande-bh' ),
		'sabara' => array( 'Sabará', 'grande-bh' ),
		'minas-gerais' => array( 'Minas Gerais', '' ),
		'politica' => array( 'Política', '' ),
		'comercio' => array( 'Comércio', '' ),
		'brasil' => array( 'Brasil', '' ),
		'mundo' => array( 'Mundo', '' ),
		'esporte' => array( 'Esporte', '' ),
		'atletico' => array( 'Atlético', 'esporte' ),
		'cruzeiro' => array( 'Cruzeiro', 'esporte' ),
		'america' => array( 'América', 'esporte' ),
		'entretenimento' => array( 'Entretenimento', '' ),
		'saude' => array( 'Saúde', '' ),
		'educacao' => array( 'Educação', '' ),
		'luto' => array( 'Luto', '' ),
	);
	foreach ( $cats as $slug => $c ) {
		if ( get_category_by_slug( $slug ) ) continue;
		$pai = $c[1] ? get_category_by_slug( $c[1] ) : null;
		wp_insert_term( $c[0], 'category', array( 'slug' => $slug, 'parent' => $pai ? $pai->term_id : 0 ) );
	}
	if ( false !== strpos( get_option( 'blogname' ), 'hostingersite' ) || '' === get_option( 'blogname' ) ) update_option( 'blogname', 'Portal ONE News' );
	update_option( 'blogdescription', 'O maior ecossistema de notícias da Região Metropolitana de Belo Horizonte' );
	update_option( 'timezone_string', 'America/Sao_Paulo' );
	update_option( 'date_format', 'd/m/Y' );
	update_option( 'time_format', 'H:i' );
	update_option( 'show_on_front', 'posts' );
	global $wp_rewrite;
	$wp_rewrite->set_permalink_structure( '/%category%/%postname%/' );
	flush_rewrite_rules();
	update_option( 'po_setup', '2.0' );
	set_transient( 'po_setup_ok', 1, 300 );
} );
add_action( 'admin_notices', function () {
	if ( get_transient( 'po_setup_ok' ) ) {
		delete_transient( 'po_setup_ok' );
		echo '<div class="notice notice-success"><p><strong>Portal ONE News:</strong> tema 2.0 configurado: editorias, links dos portais (/portal-luziense/, /portal-comercio/, /portal-politica/), fuso de Brasília e links das notícias.</p></div>';
	}
} );

/* ---------- versão 2.4: mais cidades, colunistas cadastrados e correção da chuva de Pedro Leopoldo (roda uma vez) ---------- */
add_action( 'init', function () {
	if ( get_option( 'po_setup_243' ) === '1' ) return;
	$pai = get_category_by_slug( 'grande-bh' );
	foreach ( array( 'pedro-leopoldo' => 'Pedro Leopoldo', 'matozinhos' => 'Matozinhos', 'jaboticatubas' => 'Jaboticatubas', 'venda-nova' => 'Venda Nova', 'nova-lima' => 'Nova Lima', 'ibirite' => 'Ibirité', 'esmeraldas' => 'Esmeraldas', 'sao-jose-da-lapa' => 'São José da Lapa' ) as $sl => $nm ) {
		if ( ! get_category_by_slug( $sl ) ) wp_insert_term( $nm, 'category', array( 'slug' => $sl, 'parent' => $pai ? $pai->term_id : 0 ) );
	}
	/* a notícia da chuva em Pedro Leopoldo tinha ido para "Sem categoria" */
	$pl = get_category_by_slug( 'pedro-leopoldo' );
	if ( $pl ) foreach ( get_posts( array( 'meta_key' => 'po_origem', 'meta_value' => '190931_47', 'posts_per_page' => 1, 'post_status' => 'any' ) ) as $p ) wp_set_post_categories( $p->ID, array( $pl->term_id ) );
	/* colunistas */
	$cols = array(
		array( 'israel-fernandes', 'Israel Fernandes', 'Israel', 'Fernandes', 'Comunicação e marketing', 'Jornalista e especialista em comunicação e marketing' ),
		array( 'jota-bertoldo', 'Jota Bertoldo', 'Jota', 'Bertoldo', 'Engenharia, Tecnologia e Mercado Aeronáutico', 'Engenharia, Tecnologia e Mercado Aeronáutico' ),
		array( 'paulo-alexandre', 'Paulo Alexandre', 'Paulo', 'Alexandre', 'Cientista político', 'Cientista político' ),
	);
	foreach ( $cols as $c ) {
		$u = get_user_by( 'login', $c[0] );
		if ( ! $u ) {
			$uid = wp_insert_user( array( 'user_login' => $c[0], 'user_pass' => wp_generate_password( 32 ), 'display_name' => $c[1], 'first_name' => $c[2], 'last_name' => $c[3], 'nickname' => $c[1], 'role' => 'author', 'user_email' => $c[0] . '@colunistas.portalonenews.invalid' ) );
			if ( is_wp_error( $uid ) ) continue;
		} else $uid = $u->ID;
		update_user_meta( $uid, 'po_coluna', $c[4] );
		update_user_meta( $uid, 'po_quem', $c[5] );
		update_user_meta( $uid, 'po_foto', get_template_directory_uri() . '/assets/colunistas/' . $c[0] . '.jpg' );
	}
	flush_rewrite_rules( false );
	update_option( 'po_setup_243', '1' );
	set_transient( 'po_setup_24_ok', 1, 300 );
} );
add_action( 'admin_notices', function () {
	if ( get_transient( 'po_setup_24_ok' ) ) {
		delete_transient( 'po_setup_24_ok' );
		echo '<div class="notice notice-success"><p><strong>Portal ONE News 2.4:</strong> colunistas cadastrados (Israel Fernandes, Jota Bertoldo e Paulo Alexandre), novas cidades criadas e canal do WhatsApp configurado. Para cadastrar outro colunista: Usuários &gt; Adicionar novo (função Autor) e preencha "Nome da coluna" no perfil.</p></div>';
	}
} );

/* ---------- robô de notícias: o site busca as notícias novas a cada 15 minutos ---------- */
define( 'PO_FEED', 'https://api.github.com/repos/estudioeleve/portal-artes-feed/contents/dados/site.json' );
add_filter( 'cron_schedules', function ( $s ) {
	$s['po_15min'] = array( 'interval' => 900, 'display' => 'A cada 15 minutos' );
	return $s;
} );
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'po_importar' ) ) wp_schedule_event( time() + 60, 'po_15min', 'po_importar' );
} );
add_action( 'po_importar', 'po_importar_noticias' );
function po_importar_noticias() {
	if ( get_option( 'po_robo_pausado' ) ) return;
	$r = wp_remote_get( PO_FEED, array( 'timeout' => 30, 'headers' => array( 'Accept' => 'application/vnd.github.raw', 'User-Agent' => 'PortalONENews-WordPress' ) ) );
	if ( is_wp_error( $r ) || 200 !== wp_remote_retrieve_response_code( $r ) ) { update_option( 'po_robo_ultimo', current_time( 'mysql' ) . ' · erro ao buscar o arquivo' ); return; }
	$lista = json_decode( wp_remote_retrieve_body( $r ), true );
	if ( ! is_array( $lista ) ) return;
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$robo = get_user_by( 'login', 'robo-portal' );
	if ( ! $robo ) {
		$uid = wp_insert_user( array( 'user_login' => 'robo-portal', 'user_pass' => wp_generate_password( 32 ), 'display_name' => 'Redação Portal ONE News', 'role' => 'author', 'user_email' => 'robo@portalonenews.invalid' ) );
		$robo = is_wp_error( $uid ) ? null : get_user_by( 'id', $uid );
	}
	$novos = 0;
	foreach ( array_slice( $lista, -200 ) as $n ) {
		if ( empty( $n['id'] ) || empty( $n['titulo'] ) ) continue;
		$ja = get_posts( array( 'post_type' => 'post', 'post_status' => 'any', 'meta_key' => 'po_origem', 'meta_value' => $n['id'], 'fields' => 'ids', 'posts_per_page' => 1 ) );
		if ( $ja ) continue;
		$cat = get_category_by_slug( sanitize_title( $n['categoria'] ) );
		$id = wp_insert_post( array(
			'post_title' => wp_strip_all_tags( $n['titulo'] ),
			'post_content' => wp_kses_post( $n['texto'] ),
			'post_excerpt' => sanitize_text_field( $n['linha_fina'] ),
			'post_status' => 'publish',
			'post_author' => $robo ? $robo->ID : 1,
			'post_date' => ! empty( $n['data'] ) ? wp_date( 'Y-m-d H:i:s', strtotime( $n['data'] ) ) : current_time( 'mysql' ),
			'post_category' => $cat ? array( $cat->term_id ) : array(),
		) );
		if ( ! $id || is_wp_error( $id ) ) continue;
		update_post_meta( $id, 'po_origem', sanitize_text_field( $n['id'] ) );
		update_post_meta( $id, 'po_linha_fina', sanitize_text_field( $n['linha_fina'] ) );
		update_post_meta( $id, 'po_credito_foto', sanitize_text_field( $n['credito_foto'] ) );
		update_post_meta( $id, 'po_fonte', sanitize_text_field( $n['fonte'] ) );
		if ( ! empty( $n['resumos'] ) ) update_post_meta( $id, 'po_resumos', sanitize_textarea_field( $n['resumos'] ) );
		if ( ! empty( $n['foto'] ) && 0 === strpos( $n['foto'], 'https://raw.githubusercontent.com/estudioeleve/' ) ) {
			$mid = media_sideload_image( $n['foto'], $id, wp_strip_all_tags( $n['titulo'] ), 'id' );
			if ( ! is_wp_error( $mid ) ) set_post_thumbnail( $id, $mid );
		}
		$novos++;
	}
	update_option( 'po_robo_ultimo', current_time( 'mysql' ) . ' · ' . $novos . ' notícia(s) nova(s)' );
}
/* painel: ver o robô e buscar agora */
add_action( 'admin_menu', function () {
	add_menu_page( 'Robô de notícias', 'Robô de notícias', 'manage_options', 'po-robo', 'po_pagina_robo', 'dashicons-rss', 3 );
} );
function po_pagina_robo() {
	if ( isset( $_POST['po_acao'] ) && check_admin_referer( 'po_robo' ) ) {
		if ( 'buscar' === $_POST['po_acao'] ) po_importar_noticias();
		if ( 'pausar' === $_POST['po_acao'] ) update_option( 'po_robo_pausado', 1 );
		if ( 'ligar' === $_POST['po_acao'] ) delete_option( 'po_robo_pausado' );
	}
	$pausado = get_option( 'po_robo_pausado' );
	echo '<div class="wrap"><h1>Robô de notícias</h1>';
	echo '<p>O site busca sozinho, a cada 15 minutos, as notícias que o robô publica no Instagram do Portal, com texto completo e foto.</p>';
	echo '<p><strong>Situação:</strong> ' . ( $pausado ? 'pausado' : 'ligado' ) . '<br><strong>Última busca:</strong> ' . esc_html( get_option( 'po_robo_ultimo', 'ainda não buscou' ) ) . '</p>';
	echo '<form method="post">';
	wp_nonce_field( 'po_robo' );
	echo '<button class="button button-primary" name="po_acao" value="buscar">Buscar notícias agora</button> ';
	echo $pausado ? '<button class="button" name="po_acao" value="ligar">Ligar o robô</button>' : '<button class="button" name="po_acao" value="pausar">Pausar o robô</button>';
	echo '</form></div>';
}

/** Card de vídeo: capa com botão play; ao tocar, vira o player (assets/tema.js). */
function po_yt_id( $url ) {
	if ( preg_match( '~(?:youtu\.be/|youtube\.com/(?:watch\?(?:.*&)?v=|embed/|shorts/|live/))([A-Za-z0-9_-]{11})~', (string) $url, $m ) ) return $m[1];
	return '';
}
function po_video_card( $v ) {
	$url = get_post_meta( $v->ID, 'po_url', true );
	$rede = false !== strpos( (string) $url, 'instagram' ) ? 'Instagram · Reels' : 'YouTube';
	if ( has_post_thumbnail( $v ) ) $capa = get_the_post_thumbnail( $v, 'po-card', array( 'alt' => '', 'loading' => 'lazy' ) );
	elseif ( $yt = po_yt_id( $url ) ) $capa = '<img src="' . esc_url( 'https://i.ytimg.com/vi/' . $yt . '/hqdefault.jpg' ) . '" alt="" loading="lazy">';
	else $capa = '';
	echo '<div><button class="vid" type="button" data-embed="emb-' . esc_attr( $v->ID ) . '"><span class="cap">' . $capa . '<span class="play"></span></span><b>' . esc_html( get_the_title( $v ) ) . '</b><span class="rede">' . esc_html( $rede ) . '</span></button><template id="emb-' . esc_attr( $v->ID ) . '">' . po_embed_video( $url ) . '</template></div>';
}
/** Mais lidas dos últimos 3 dias (completa com as mais recentes). */
function po_mais_lidas( $qtd = 6, $classe = '' ) {
	$lidas = get_posts( array( 'posts_per_page' => $qtd, 'meta_key' => 'po_views', 'orderby' => 'meta_value_num', 'order' => 'DESC', 'date_query' => array( array( 'after' => '3 days ago' ) ), 'ignore_sticky_posts' => true ) );
	if ( count( $lidas ) < $qtd ) $lidas = array_merge( $lidas, get_posts( array( 'posts_per_page' => $qtd - count( $lidas ), 'post__not_in' => wp_list_pluck( $lidas, 'ID' ), 'ignore_sticky_posts' => true ) ) );
	echo '<ol class="lidas ' . esc_attr( $classe ) . '">';
	foreach ( $lidas as $p ) echo '<li><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a></li>';
	echo '</ol>';
}

/* painel: colunas da lista de anúncios (onde aparece e até quando) */
add_filter( 'manage_po_anuncio_posts_columns', function ( $c ) {
	return array( 'cb' => $c['cb'], 'title' => 'Anunciante', 'po_onde' => 'Onde aparece', 'po_periodo' => 'Período', 'date' => 'Criado em' );
} );
add_action( 'manage_po_anuncio_posts_custom_column', function ( $col, $id ) {
	$nomes = array( 'topo' => 'Banner grande 1 (970 × 90)', 'meio' => 'Banner grande 2 (970 × 90)', 'lateral' => 'Quadrado 1 (300 × 250)', 'lateral2' => 'Quadrado 2 (300 × 250)', 'vitrine' => 'Vitrine', 'videos' => 'Patrocínio dos vídeos', 'coluna' => 'Patrocínio de coluna', 'portal-luziense' => 'Patrocínio Portal Luziense', 'portal-comercio' => 'Patrocínio Portal Comércio', 'portal-politica' => 'Patrocínio Portal Política' );
	if ( 'po_onde' === $col ) { $p = get_post_meta( $id, 'po_posicao', true ); echo esc_html( isset( $nomes[ $p ] ) ? $nomes[ $p ] : '—' ); }
	if ( 'po_periodo' === $col ) {
		$ini = get_post_meta( $id, 'po_inicio', true ); $fim = get_post_meta( $id, 'po_fim', true );
		echo esc_html( ( $ini ? wp_date( 'd/m/Y', strtotime( $ini ) ) : 'já' ) . ' até ' . ( $fim ? wp_date( 'd/m/Y', strtotime( $fim ) ) : 'sem data' ) );
		if ( $fim && $fim < wp_date( 'Y-m-d' ) ) echo ' <strong style="color:#b32d2e">(vencido)</strong>';
	}
}, 10, 2 );
