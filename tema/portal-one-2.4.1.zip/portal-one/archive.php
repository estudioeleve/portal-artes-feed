<?php
/* Listas: portal (Luziense, Comércio, Política), colunista, editoria, vídeos e busca. */
get_header();
$portal = get_query_var( 'po_portal' );
$todos  = po_portais();
$portal = isset( $todos[ $portal ] ) ? $portal : '';

if ( $portal ) :
  $p = $todos[ $portal ]; ?>
  <div class="cab-portal f-<?php echo esc_attr( $p['cor'] ); ?>"><div class="w">
    <?php echo $p['logo'] ? '<img src="' . esc_url( $p['logo'] ) . '" alt="">' : ''; ?>
    <h1 class="nm<?php echo $p['logo'] ? ' so-leitor' : ''; ?>" style="margin:0"><?php echo esc_html( $p['nome'] ); ?></h1>
    <?php echo po_patrocinador( 'portal-' . $portal ); ?>
    <p><?php echo esc_html( $p['desc'] ); ?> Um portal do ecossistema Portal ONE News.</p>
  </div></div>

<?php elseif ( is_author() ) :
  $u = get_queried_object();
  $quem = get_user_meta( $u->ID, 'po_quem', true ); ?>
  <div class="cab-blog"><div class="w">
    <?php echo po_avatar( $u ); ?>
    <div class="tx">
      <span class="tag"><?php echo esc_html( get_user_meta( $u->ID, 'po_coluna', true ) ? get_user_meta( $u->ID, 'po_coluna', true ) : 'Coluna' ); ?></span>
      <h1><?php echo esc_html( $u->display_name ); ?></h1>
      <?php if ( $quem ) echo '<span class="quem">' . esc_html( $quem ) . '</span>'; ?>
      <?php if ( $u->description ) echo '<p>' . esc_html( $u->description ) . '</p>'; ?>
    </div>
  </div></div>

<?php else :
  if ( is_post_type_archive( 'po_video' ) ) { $tit = 'Vídeos'; $cor = 'azul'; }
  elseif ( is_search() ) { $tit = 'Busca: ' . get_search_query(); $cor = 'azul'; }
  elseif ( is_category() ) {
    $tit = single_term_title( '', false );
    $t = get_queried_object();
    $mapa = array( 'esporte' => 'verde', 'atletico' => 'verde', 'cruzeiro' => 'verde', 'america' => 'verde', 'entretenimento' => 'laranja', 'politica' => 'preto', 'comercio' => 'comercio', 'luto' => 'preto' );
    $cor = isset( $mapa[ $t->slug ] ) ? $mapa[ $t->slug ] : 'azul';
  } else { $tit = get_the_archive_title(); $cor = 'azul'; } ?>
  <div class="w cab-ed"><h1 class="c-<?php echo esc_attr( $cor ); ?>"><?php echo esc_html( $tit ); ?></h1></div>
<?php endif; ?>

<div class="w">
<?php po_banner( 'topo', 'lb', '970 × 90' ); ?>
<?php if ( is_post_type_archive( 'po_video' ) ) : ?>
  <div class="grade-vid"><?php while ( have_posts() ) { the_post(); po_video_card( get_post() ); } ?></div>
  <div class="paginacao" style="margin-bottom:40px"><?php echo paginate_links( array( 'prev_text' => '‹ Anteriores', 'next_text' => 'Próximas ›' ) ); ?></div>
<?php else : ?>
  <div class="pag-lista">
    <div>
      <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); $ed = po_editoria(); ?>
        <a class="item-l" href="<?php the_permalink(); ?>">
          <?php if ( has_post_thumbnail() ) the_post_thumbnail( 'po-card', array( 'class' => 'foto', 'alt' => '', 'loading' => 'lazy' ) ); ?>
          <div>
            <?php if ( $ed ) echo '<span class="ed c-' . esc_attr( po_cor( get_the_ID() ) ) . '">' . esc_html( $ed->name ) . '</span>'; ?>
            <h2><?php the_title(); ?></h2>
            <?php $lf = get_post_meta( get_the_ID(), 'po_linha_fina', true ); if ( $lf ) echo '<p>' . esc_html( $lf ) . '</p>'; ?>
            <span class="hora"><?php echo esc_html( po_hora() ); ?></span>
          </div>
        </a>
      <?php endwhile; else : echo '<p style="padding-block:24px;color:var(--sub)">' . ( $portal ? 'As notícias do ' . esc_html( $todos[ $portal ]['nome'] ) . ' aparecem aqui assim que forem publicadas.' : 'Ainda não há notícias aqui.' ) . '</p>'; endif; ?>
      <div class="paginacao"><?php echo paginate_links( array( 'prev_text' => '‹ Anteriores', 'next_text' => 'Próximas ›' ) ); ?></div>
    </div>
    <aside class="lado-mat">
      <?php if ( is_author() ) { $pc = po_patrocinador( 'coluna', get_queried_object_id() ); if ( $pc ) echo '<div class="pat-col"><small>Coluna oferecida por</small>' . str_replace( 'Oferecido por ', '', $pc ) . '</div>'; } ?>
      <?php po_banner( 'lateral', 'ret', '300 × 250' ); ?>
      <div><h2>Mais lidas</h2><?php po_mais_lidas( 5, 'uma' ); ?></div>
    <?php po_banner( 'lateral2', 'ret', '300 × 250' ); ?>
    </aside>
  </div>
<?php endif; ?>
</div>
<?php get_footer(); ?>
