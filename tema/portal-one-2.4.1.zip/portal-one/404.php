<?php get_header(); ?>
<div class="w"><article class="materia"><h1>Página não encontrada</h1><p class="linha-fina">Essa notícia pode ter mudado de endereço.</p><div class="compart"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Voltar para a página inicial</a></div></article></div>
<?php get_footer(); ?>
