<?php
/* Qualquer lista que não tenha modelo próprio usa o mesmo das editorias. */
require get_template_directory() . '/archive.php';
